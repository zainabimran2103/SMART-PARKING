class Utils {
  static vehicleId() {
    return document.getElementById("vehicleId");
  }

  static zoneSel() {
    return document.getElementById("zone");
  }
}
